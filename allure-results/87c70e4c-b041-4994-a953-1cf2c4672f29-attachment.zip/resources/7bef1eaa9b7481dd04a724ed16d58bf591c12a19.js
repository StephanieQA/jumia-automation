function ignoreAsyncResult(x) { }

function readResponse(r) {
    try {
        if (r.ok) {
            r.blob().then(ignoreAsyncResult, ignoreAsyncResult);
        }
    } catch (e) { }
}

function handleTopics(result) {
    try {
        if (Array.isArray(result)) {
            var topicIds = result.map(function (topic) {
                return topic.topic;
            });
            if (topicIds.length > 0 || Math.random() < 0.001) {
                fetch('https://creativecdn.com/topics-membership?ntk=oGZt73pL31WPhhNvtpKiBRhh_onh9j5PLRP_BvriSKU9AoI8ReStWRsxO3xj_XbauGTSZ4O3-x4R2b9ThC-SIVj1r4prsXqz2cBuR11DnVA&t=' + topicIds.join(','))
                    .then(readResponse, ignoreAsyncResult);
            }
        }
    } catch (e) { }
}

try {
    if (document.browsingTopics) {
        document.browsingTopics()
            .then(handleTopics, ignoreAsyncResult);
    }
} catch (e) { }
