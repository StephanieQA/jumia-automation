    function addToIG(ig) {
        if (navigator.joinAdInterestGroup) {
            try {
                navigator.joinAdInterestGroup(ig, 2592000000);
            } catch(e) {
                fetch('https://creativecdn.com/ig-membership' + '?ig='+ encodeURIComponent(ig.name) + '&err=' +  encodeURIComponent(e.toString().substring(0, 256))).catch(() => {});
            }
        }
    }

    addToIG({"owner":"https://f.creativecdn.com","name":"gwhvAkpI80F09M5zwA7v","biddingLogicURL":"https://f.creativecdn.com/statics/buyer.js","biddingWasmHelperURL":"https://f.creativecdn.com/statics/buyer.wasm","trustedBiddingSignalsURL":"https://f.creativecdn.com/bidder/tbsweb/bids","trustedBiddingSignalsKeys":["v5_Se2Z7HQirY-pwUVcQeV1_apKKPjoQATniEvtTlvwqITaZxc2HuHGZ3yKwuH0LZhx87WRqY-qE9O5APQIQWrCO3PLsxByHtYhyrTkwe_bI58"],"ads":[],"adComponents":[],"priority":0.0,"executionMode":"compatibility","auctionServerRequestFlags":["omit-ads"],"updateURL":"https://f.creativecdn.com/update-ig?ntk=f61rYpvMcbJ_8or7saV-9hwi3XY3YFudmr29EUxh3G_HTHvLWYSgzaW8njolkXHltw9scC6S5livvzNpSmN_ek3i6209Kk_swtKPggT_Zc-If9pdoJ5EDAJEh8RQfZjQ","privateAggregationConfig":{"aggregationCoordinatorOrigin":"https://publickeyservice.msmt.gcp.privacysandboxservices.com"}});
addToIG({"owner":"https://f.creativecdn.com","name":"gwhvAkpI80F09M5zwNEW","biddingLogicURL":"https://f.creativecdn.com/statics/buyer.js","biddingWasmHelperURL":"https://f.creativecdn.com/statics/buyer.wasm","trustedBiddingSignalsURL":"https://f.creativecdn.com/bidder/tbsweb/bids","trustedBiddingSignalsKeys":["v5_Se2Z7HQirY-pwUVcQeV1_apKKPjoQATniEvtTlvwqITaZxc2HuHGZ3yKwuH0LZhx6nxPKxt5VM5WubUZeE1G5awM29TneHASknNcglgJvo0"],"ads":[],"adComponents":[],"priority":0.0,"executionMode":"compatibility","auctionServerRequestFlags":["omit-ads"],"updateURL":"https://f.creativecdn.com/update-ig?ntk=f61rYpvMcbJ_8or7saV-9hgBgo0nah63tR9xqpLYxDN88lNTKK2z65P3QxyJkcEvnnIzOG-y0pjE-GVB0-YaYd2O7YHYUCwzHoaTKtKqxapiosiclXSaStME1DmzjoCQ","privateAggregationConfig":{"aggregationCoordinatorOrigin":"https://publickeyservice.msmt.gcp.privacysandboxservices.com"}});
